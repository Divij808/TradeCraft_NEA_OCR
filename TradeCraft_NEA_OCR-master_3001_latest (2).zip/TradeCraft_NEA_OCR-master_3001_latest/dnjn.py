import pyautogui
screenshot = pyautogui.screenshot()
screenshot.save("my_screenshot.png")
screenshot.show()