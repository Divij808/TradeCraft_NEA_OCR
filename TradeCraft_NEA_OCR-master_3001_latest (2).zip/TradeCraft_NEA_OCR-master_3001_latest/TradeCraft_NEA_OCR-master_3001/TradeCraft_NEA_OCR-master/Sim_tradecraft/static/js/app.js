// static/js/app.js
// Minimal validation functions so forms won't be blocked.
// Add real checks if you want client-side validation.

function validateSignUpForm() {
  // Example: make the browser perform built-in validation and then return true.
  // If you want more checks, implement them here and return false on error.
  return true;
}

function validateLoginForm() {
  return true;
}
